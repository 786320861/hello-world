package com.example.chengdudemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChengdudemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
