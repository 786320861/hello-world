package com.example.chengdudemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChengdudemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChengdudemoApplication.class, args);
    }

}
